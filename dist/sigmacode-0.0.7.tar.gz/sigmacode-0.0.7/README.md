# sigmacode

**A Python Library for real sigmas!**

```
pip install sigmacode
```
__version__ = "0.0.7"

from .terminal import cls, center, clr